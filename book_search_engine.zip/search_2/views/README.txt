A Pen created at CodePen.io. You can find this one at https://codepen.io/XyZXyZealot/pen/gZXexy.

 Colorful text animation

Fluid and configurable colorful text animation module made with scss.
Use it wherever you want but please give credit ;)

In use http://hendrysadrak.com